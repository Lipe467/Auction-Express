export const IP_API = "http://192.168.137.1:8080";
export const IP_SOCKET = "ws://192.168.137.1:8000/ws";